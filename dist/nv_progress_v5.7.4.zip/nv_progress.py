"""A daily progress log viewer plugin for novelibre.

Requires Python 3.7+
Copyright (c) Peter Triesberger
For further information see https://github.com/peter88213/nv_progress
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import gettext
import locale
import os
import sys

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation(
        'nv_progress',
        LOCALE_PATH,
        languages=[CURRENT_LANGUAGE],
    )
    _ = t.gettext
except:

    def _(message):
        return message

from abc import ABC, abstractmethod
from pathlib import Path



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass

import tkinter as tk


class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''
    HELP_SITE = None
    HELP_PAGE = None

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

        self._icon = None

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def uninstall(self):
        pass

    def _add_help_menu_entry(self, label):

        def open_help():
            self._ctrl.open_help(
                page=self.HELP_PAGE,
                site=self.HELP_SITE
            )

        self._ui.helpMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=open_help,
        )

    def _get_icon(self, fileName):
        if self._ctrl.get_preferences().get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
            icon = tk.PhotoImage(file=f'{iconPath}/{fileName}')
        except:
            icon = None
        return icon
from pathlib import Path



def set_icon(widget, icon='logo', path=None, default=True):
    if path is None:
        path = os.path.dirname(sys.argv[0])
        if not path:
            path = '.'
        path = f'{path}/icons'
    try:
        pic = tk.PhotoImage(file=f'{path}/{icon}.png')
        widget.iconphoto(default, pic)
    except:
        return False

    return True

from tkinter import ttk

from abc import ABC, abstractmethod


class Observer(ABC):

    @abstractmethod
    def refresh(self):
        pass
import platform



class GenericKeys:

    QUIT_PROGRAM = ('<Control-q>', f'{_("Ctrl")}-Q')


class MacKeys(GenericKeys):

    QUIT_PROGRAM = ('<Command-q>', 'Cmd-Q')



class WindowsKeys(GenericKeys):

    QUIT_PROGRAM = ('<Alt-F4>', 'Alt-F4')


if platform.system() == 'Windows':
    PLATFORM = 'win'
    KEYS = WindowsKeys()
elif platform.system() in ('Linux', 'FreeBSD'):
    PLATFORM = 'ix'
    KEYS = GenericKeys()
elif platform.system() == 'Darwin':
    PLATFORM = 'mac'
    KEYS = MacKeys()
else:
    PLATFORM = ''
    KEYS = GenericKeys()

from datetime import date



class ProgressView(tk.Toplevel, Observer, SubController):

    MIN_HEIGHT = 400
    MIN_WIDTH = 200

    def __init__(self, model, prefs):
        tk.Toplevel.__init__(self)
        self._prefs = prefs

        self.geometry(self._prefs['window_geometry'])
        self.minsize(self.MIN_WIDTH, self.MIN_HEIGHT)

        self.lift()
        self.focus()
        self.protocol("WM_DELETE_WINDOW", self.on_quit)
        if PLATFORM != 'win':
            self.bind(KEYS.QUIT_PROGRAM[0], self.on_quit)

        columns = (
            'date',
            'wordCount',
            'wordCountDelta',
            'totalWordCount',
            'totalWordCountDelta',
            'spacer',
        )
        self.tree = ttk.Treeview(
            self,
            selectmode='none',
            columns=columns,
        )
        scrollY = ttk.Scrollbar(
            self.tree,
            orient='vertical',
            command=self.tree.yview,
        )
        self.tree.configure(yscrollcommand=scrollY.set)
        scrollY.pack(side='right', fill='y')
        self.tree.pack(fill='both', expand=True)
        self.tree.heading('date', text=_('Date'))
        self.tree.heading('wordCount', text=_('Words total'))
        self.tree.heading('wordCountDelta', text=_('Daily'))
        self.tree.heading('totalWordCount', text=_('With unused'))
        self.tree.heading('totalWordCountDelta', text=_('Daily'))
        self.tree.column('#0', width=0)
        self.tree.column(
            'date',
            anchor='center',
            width=self._prefs['date_width'],
            stretch=False,
        )
        self.tree.column(
            'wordCount',
            anchor='center',
            width=self._prefs['wordcount_width'],
            stretch=False,
        )
        self.tree.column(
            'wordCountDelta',
            anchor='center',
            width=self._prefs['wordcount_delta_width'],
            stretch=False,
        )
        self.tree.column(
            'totalWordCount',
            anchor='center',
            width=self._prefs['totalcount_width'],
            stretch=False,
        )
        self.tree.column(
            'totalWordCountDelta',
            anchor='center',
            width=self._prefs['totalcount_delta_width'],
            stretch=False,
        )

        self.tree.tag_configure('positive',)
        self.tree.tag_configure('negative', foreground='#ff0000')

        ttk.Button(
            self,
            text=_('Close'),
            command=self.on_quit,
        ).pack(side='right', padx=5, pady=5)

        self._mdl = model
        self.isOpen = True
        self._build_tree()
        self._mdl.add_observer(self)

    def on_quit(self, event=None):
        self._mdl.delete_observer(self)
        self._prefs['window_geometry'] = self.winfo_geometry()
        self._prefs['date_width'] = self.tree.column(
            'date', 'width')
        self._prefs['wordcount_width'] = self.tree.column(
            'wordCount', 'width')
        self._prefs['wordcount_delta_width'] = self.tree.column(
            'wordCountDelta', 'width')
        self._prefs['totalcount_width'] = self.tree.column(
            'totalWordCount', 'width')
        self._prefs['totalcount_delta_width'] = self.tree.column(
            'totalWordCountDelta', 'width')
        self.destroy()
        self.isOpen = False

    def refresh(self):
        self._build_tree()

    def _reset_tree(self):
        for child in self.tree.get_children(''):
            self.tree.delete(child)

    def _build_tree(self):
        self._reset_tree()
        wcLog = {}

        for wcDate in self._mdl.prjFile.wcLog:
            sessionDate = date.fromisoformat(wcDate).strftime('%x')
            wcLog[sessionDate] = self._mdl.prjFile.wcLog[wcDate]

        for wcDate in self._mdl.prjFile.wcLogUpdate:
            sessionDate = date.fromisoformat(wcDate).strftime('%x')
            wcLog[sessionDate] = self._mdl.prjFile.wcLogUpdate[wcDate]

        newCount, newTotalCount = self._mdl.prjFile.count_words()
        today = date.today().strftime('%x')
        wcLog[today] = [newCount, newTotalCount]

        lastCount = 0
        lastTotalCount = 0
        for wc in wcLog:
            countDiffInt = wcLog[wc][0] - lastCount
            totalCountDiffInt = wcLog[wc][1] - lastTotalCount
            if countDiffInt == 0 and totalCountDiffInt == 0:
                continue

            if countDiffInt > 0:
                nodeTags = ('positive')
            else:
                nodeTags = ('negative')
            columns = [
                wc,
                str(wcLog[wc][0]),
                str(countDiffInt),
                str(wcLog[wc][1]),
                str(totalCountDiffInt),
            ]
            lastCount = wcLog[wc][0]
            lastTotalCount = wcLog[wc][1]
            startIndex = '0'
            self.tree.insert(
                '',
                startIndex,
                iid=wc,
                values=columns,
                tags=nodeTags,
                open=True,
            )



class ProgressService(SubController):
    INI_FILENAME = 'progress.ini'
    INI_FILEPATH = '.novx/config'
    SETTINGS = dict(
        window_geometry='510x440',
        date_width=100,
        wordcount_width=100,
        wordcount_delta_width=100,
        totalcount_width=100,
        totalcount_delta_width=100,
    )
    OPTIONS = dict(
        force_logging=True,
    )

    def __init__(self, model, view):
        self._mdl = model
        self._ui = view
        self.progressView = None

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/{self.INI_FILEPATH}'
        except:
            configDir = '.'
        self.configuration = self._mdl.nvService.new_configuration(
            settings=self.SETTINGS,
            options=self.OPTIONS,
            filePath=f'{configDir}/{self.INI_FILENAME}',
        )
        self.configuration.read()
        self._prefs = {}
        self._prefs.update(self.configuration.settings)
        self._prefs.update(self.configuration.options)

    def on_close(self):
        self.on_quit()

    def on_open(self):
        if self._prefs['force_logging'] and not self._mdl.novel.saveWordCount:
            self._mdl.novel.saveWordCount = True
            self._ui.set_status(f"#{_('Word count logging is enabled')}.")

    def on_quit(self):
        if self.progressView is not None:
            if self.progressView.isOpen:
                self.progressView.on_quit()

        for keyword in self._prefs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = self._prefs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = self._prefs[keyword]
        self.configuration.write()

    def start_viewer(self, windowTitle):
        if self.progressView:
            if self.progressView.isOpen:
                if self.progressView.state() == 'iconic':
                    self.progressView.state('normal')
                self.progressView.lift()
                self.progressView.focus()
                return

        self.progressView = ProgressView(
            self._mdl,
            self._prefs,
        )
        self.progressView.title(
            f'{self._mdl.novel.title} - {windowTitle}'
        )
        set_icon(self.progressView, icon='progress', default=False)



class Plugin(PluginBase):
    VERSION = '5.7.4'
    API_VERSION = '5.63'
    DESCRIPTION = 'A daily progress log viewer'
    URL = 'https://github.com/peter88213/nv_progress'
    HELP_PAGE = 'nv_progress'

    FEATURE = _('Daily progress log')

    def install(self, model, view, controller):
        """Install the plugin at runtime.
        
        Positional arguments:
            model -- reference to the novelibre main model instance.
            view -- reference to the novelibre main view instance.
            controller -- reference to the novelibre main controller.

        Extends the superclass method.
        """
        super().install(model, view, controller)
        self.progressService = ProgressService(model, view)
        self._icon = self._get_icon('progress.png')


        def start_viewer():
            self.progressService.start_viewer(self.FEATURE)

        label = self.FEATURE
        self._ui.toolsMenu.add_command(
            label=label,
            image=self._icon,
            compound='left',
            command=start_viewer,
            state='disabled',
        )
        self._ui.toolsMenu.disableOnClose.append(label)

        self._add_help_menu_entry(_('Progress viewer plugin help'))

    def on_close(self):
        self.progressService.on_close()

    def on_open(self):
        self.progressService.on_open()

    def on_quit(self):
        self.progressService.on_quit()

